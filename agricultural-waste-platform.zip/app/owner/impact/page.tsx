"use client"

import { motion } from "framer-motion"
import {
  Leaf,
  Droplet,
  Wind,
  Factory,
  TrendingUp,
  TreePine,
  Recycle,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const impactStats = [
  {
    title: "CO2 Saved",
    value: "52.3",
    unit: "Tonnes",
    change: "+12%",
    icon: Leaf,
    color: "primary",
    description: "Carbon dioxide emissions prevented",
  },
  {
    title: "Water Conserved",
    value: "125K",
    unit: "Liters",
    change: "+8%",
    icon: Droplet,
    color: "secondary",
    description: "Water saved from pollution",
  },
  {
    title: "Air Quality",
    value: "85%",
    unit: "Improved",
    change: "+5%",
    icon: Wind,
    color: "accent",
    description: "Regional air quality improvement",
  },
  {
    title: "Pollution Reduced",
    value: "38.5",
    unit: "Tonnes",
    change: "+15%",
    icon: Factory,
    color: "primary",
    description: "Total pollution prevented",
  },
]

const co2TrendData = [
  { month: "Jan", saved: 3.2 },
  { month: "Feb", saved: 4.1 },
  { month: "Mar", saved: 3.8 },
  { month: "Apr", saved: 5.2 },
  { month: "May", saved: 6.5 },
  { month: "Jun", saved: 7.1 },
  { month: "Jul", saved: 8.3 },
  { month: "Aug", saved: 9.2 },
  { month: "Sep", saved: 10.5 },
  { month: "Oct", saved: 11.8 },
  { month: "Nov", saved: 13.2 },
  { month: "Dec", saved: 14.5 },
]

const productsCreatedData = [
  { name: "Biodegradable Packaging", value: 35, color: "#2E7D32" },
  { name: "Organic Fertilizer", value: 25, color: "#A5D6A7" },
  { name: "Biofuel Pellets", value: 20, color: "#FFB703" },
  { name: "Coir Products", value: 12, color: "#66BB6A" },
  { name: "Paper Products", value: 8, color: "#81C784" },
]

const wasteTypeImpact = [
  { type: "Rice Straw", co2: 22.5, pollution: 15.2 },
  { type: "Coconut Husks", co2: 12.3, pollution: 8.5 },
  { type: "Sugarcane Bagasse", co2: 10.8, pollution: 9.2 },
  { type: "Banana Stems", co2: 6.7, pollution: 5.6 },
]

export default function ImpactPage() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Impact Analytics</h1>
        <p className="text-muted-foreground mt-1">
          Track environmental impact and sustainability metrics
        </p>
      </div>

      {/* Impact Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {impactStats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                      stat.color === "primary"
                        ? "bg-primary/10"
                        : stat.color === "secondary"
                          ? "bg-secondary"
                          : "bg-accent/20"
                    }`}
                  >
                    <stat.icon
                      className={`w-6 h-6 ${
                        stat.color === "primary"
                          ? "text-primary"
                          : stat.color === "secondary"
                            ? "text-primary"
                            : "text-accent-foreground"
                      }`}
                    />
                  </div>
                  <span className="text-sm font-medium text-primary flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    {stat.change}
                  </span>
                </div>
                <div className="mt-4">
                  <div className="flex items-baseline gap-1">
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 + index * 0.1 }}
                      className="text-3xl font-bold text-foreground"
                    >
                      {stat.value}
                    </motion.span>
                    <span className="text-sm text-muted-foreground">{stat.unit}</span>
                  </div>
                  <p className="text-sm font-medium text-foreground mt-1">
                    {stat.title}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stat.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* CO2 Trend Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Leaf className="w-5 h-5 text-primary" />
                CO2 Savings Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={co2TrendData}>
                    <defs>
                      <linearGradient id="co2Gradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2E7D32" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#2E7D32" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#D4E5D6" />
                    <XAxis dataKey="month" stroke="#4A5568" fontSize={12} />
                    <YAxis stroke="#4A5568" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #D4E5D6",
                        borderRadius: "12px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                      labelStyle={{ color: "#1B1B1B" }}
                      formatter={(value) => [`${value} Tonnes`, "CO2 Saved"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="saved"
                      stroke="#2E7D32"
                      strokeWidth={3}
                      fill="url(#co2Gradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Products Created Pie Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Recycle className="w-5 h-5 text-primary" />
                Products Created
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={productsCreatedData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {productsCreatedData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #D4E5D6",
                        borderRadius: "12px",
                      }}
                      formatter={(value) => [`${value}%`, "Share"]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-3 mt-4">
                {productsCreatedData.slice(0, 4).map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-xs text-muted-foreground">{item.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Impact by Waste Type */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TreePine className="w-5 h-5 text-primary" />
              Impact by Waste Type
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {wasteTypeImpact.map((item, index) => (
                <motion.div
                  key={item.type}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="p-4 bg-muted/50 rounded-xl"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-foreground">{item.type}</h4>
                    <span className="text-sm text-muted-foreground">
                      Total: {(item.co2 + item.pollution).toFixed(1)}T impact
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-muted-foreground">CO2 Saved</span>
                        <span className="text-sm font-medium text-foreground">
                          {item.co2}T
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${(item.co2 / 25) * 100}%` }}
                          transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                          className="h-full bg-primary rounded-full"
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-muted-foreground">
                          Pollution Reduced
                        </span>
                        <span className="text-sm font-medium text-foreground">
                          {item.pollution}T
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${(item.pollution / 20) * 100}%` }}
                          transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                          className="h-full bg-accent rounded-full"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Environmental Progress */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Card className="bg-primary text-primary-foreground">
          <CardContent className="p-6">
            <div className="grid sm:grid-cols-3 gap-6 text-center">
              <div>
                <p className="text-4xl font-bold">52.3T</p>
                <p className="text-primary-foreground/80 text-sm mt-1">
                  Total CO2 Emissions Prevented
                </p>
              </div>
              <div>
                <p className="text-4xl font-bold">2,615</p>
                <p className="text-primary-foreground/80 text-sm mt-1">
                  Trees Equivalent Saved
                </p>
              </div>
              <div>
                <p className="text-4xl font-bold">125K</p>
                <p className="text-primary-foreground/80 text-sm mt-1">
                  Liters of Clean Water Protected
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
