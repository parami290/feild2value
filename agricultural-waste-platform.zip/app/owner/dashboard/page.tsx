"use client"

import { motion } from "framer-motion"
import {
  Users,
  Trash2,
  Coins,
  Leaf,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const kpiData = [
  {
    title: "Total Farmers",
    value: "5,247",
    change: "+12%",
    trend: "up",
    icon: Users,
  },
  {
    title: "Waste Collected",
    value: "248.5T",
    change: "+8%",
    trend: "up",
    icon: Trash2,
  },
  {
    title: "Eco-Coins Issued",
    value: "125,420",
    change: "+15%",
    trend: "up",
    icon: Coins,
  },
  {
    title: "CO2 Saved",
    value: "52.3T",
    change: "+6%",
    trend: "up",
    icon: Leaf,
  },
]

const wasteData = [
  { month: "Jan", waste: 18.2 },
  { month: "Feb", waste: 22.5 },
  { month: "Mar", waste: 19.8 },
  { month: "Apr", waste: 28.3 },
  { month: "May", waste: 32.1 },
  { month: "Jun", waste: 35.7 },
  { month: "Jul", waste: 38.2 },
  { month: "Aug", waste: 42.5 },
  { month: "Sep", waste: 48.1 },
  { month: "Oct", waste: 52.3 },
  { month: "Nov", waste: 58.7 },
  { month: "Dec", waste: 62.4 },
]

const paymentsData = [
  { month: "Jan", amount: 12500 },
  { month: "Feb", amount: 15800 },
  { month: "Mar", amount: 14200 },
  { month: "Apr", amount: 18900 },
  { month: "May", amount: 22100 },
  { month: "Jun", amount: 25400 },
  { month: "Jul", amount: 28700 },
  { month: "Aug", amount: 32100 },
  { month: "Sep", amount: 35800 },
  { month: "Oct", amount: 38200 },
  { month: "Nov", amount: 42500 },
  { month: "Dec", amount: 45800 },
]

const impactData = [
  { name: "CO2 Reduced", value: 45, color: "#2E7D32" },
  { name: "Water Saved", value: 25, color: "#A5D6A7" },
  { name: "Pollution Prevented", value: 30, color: "#FFB703" },
]

const recentActivities = [
  {
    id: 1,
    farmer: "Kamal Perera",
    action: "Submitted 120kg rice straw",
    time: "2 hours ago",
  },
  {
    id: 2,
    farmer: "Nimal Silva",
    action: "Verified and received 240 coins",
    time: "3 hours ago",
  },
  {
    id: 3,
    farmer: "Sunil Fernando",
    action: "Registered as new farmer",
    time: "5 hours ago",
  },
  {
    id: 4,
    farmer: "Anura Jayawardena",
    action: "Submitted 85kg coconut husks",
    time: "6 hours ago",
  },
]

export default function OwnerDashboardPage() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
          <p className="text-muted-foreground mt-1">
            Monitor your platform performance and metrics
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiData.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="hover:shadow-md transition-shadow duration-200">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                    <kpi.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div
                    className={`flex items-center gap-1 text-sm font-medium ${
                      kpi.trend === "up" ? "text-primary" : "text-destructive"
                    }`}
                  >
                    {kpi.trend === "up" ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    {kpi.change}
                  </div>
                </div>
                <div className="mt-4">
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="text-3xl font-bold text-foreground"
                  >
                    {kpi.value}
                  </motion.p>
                  <p className="text-sm text-muted-foreground mt-1">{kpi.title}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Waste Collection Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Waste Collected Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={wasteData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#D4E5D6" />
                    <XAxis dataKey="month" stroke="#4A5568" fontSize={12} />
                    <YAxis stroke="#4A5568" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #D4E5D6",
                        borderRadius: "12px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                      labelStyle={{ color: "#1B1B1B" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="waste"
                      stroke="#2E7D32"
                      strokeWidth={3}
                      dot={{ fill: "#2E7D32", strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, fill: "#2E7D32" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Monthly Payments Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Monthly Payments Issued</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={paymentsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#D4E5D6" />
                    <XAxis dataKey="month" stroke="#4A5568" fontSize={12} />
                    <YAxis stroke="#4A5568" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #D4E5D6",
                        borderRadius: "12px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                      labelStyle={{ color: "#1B1B1B" }}
                      formatter={(value) => [`Rs. ${value}`, "Amount"]}
                    />
                    <Bar
                      dataKey="amount"
                      fill="#A5D6A7"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Impact Ring Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.6 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Environmental Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={impactData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {impactData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#FFFFFF",
                        border: "1px solid #D4E5D6",
                        borderRadius: "12px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-4 mt-4">
                {impactData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm text-muted-foreground">{item.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.7 }}
          className="lg:col-span-2"
        >
          <Card className="h-full">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Recent Activity</CardTitle>
              <a
                href="/owner/farmers"
                className="text-sm text-primary hover:underline flex items-center gap-1"
              >
                View All <ArrowUpRight className="w-4 h-4" />
              </a>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="flex items-center gap-4 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-primary">
                        {activity.farmer.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {activity.farmer}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {activity.action}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {activity.time}
                    </span>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
