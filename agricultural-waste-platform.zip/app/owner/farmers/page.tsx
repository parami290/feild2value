"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Search,
  Filter,
  MoreVertical,
  Eye,
  CheckCircle,
  XCircle,
  MapPin,
  Trash2,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const farmersData = [
  {
    id: 1,
    name: "Kamal Perera",
    location: "Anuradhapura",
    status: "active",
    totalWaste: "1,250 kg",
    joinDate: "Jan 15, 2024",
    phone: "+94 77 123 4567",
    totalCoins: 2500,
  },
  {
    id: 2,
    name: "Nimal Silva",
    location: "Polonnaruwa",
    status: "active",
    totalWaste: "980 kg",
    joinDate: "Feb 20, 2024",
    phone: "+94 76 234 5678",
    totalCoins: 1960,
  },
  {
    id: 3,
    name: "Sunil Fernando",
    location: "Kurunegala",
    status: "pending",
    totalWaste: "0 kg",
    joinDate: "Dec 01, 2024",
    phone: "+94 71 345 6789",
    totalCoins: 0,
  },
  {
    id: 4,
    name: "Anura Jayawardena",
    location: "Matale",
    status: "active",
    totalWaste: "2,100 kg",
    joinDate: "Nov 10, 2023",
    phone: "+94 78 456 7890",
    totalCoins: 4200,
  },
  {
    id: 5,
    name: "Mahinda Rathnayake",
    location: "Hambantota",
    status: "blocked",
    totalWaste: "450 kg",
    joinDate: "Mar 05, 2024",
    phone: "+94 75 567 8901",
    totalCoins: 900,
  },
  {
    id: 6,
    name: "Ruwan Wickramasinghe",
    location: "Galle",
    status: "active",
    totalWaste: "1,800 kg",
    joinDate: "Aug 22, 2023",
    phone: "+94 77 678 9012",
    totalCoins: 3600,
  },
]

export default function FarmersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFarmer, setSelectedFarmer] = useState<typeof farmersData[0] | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const filteredFarmers = farmersData.filter(
    (farmer) =>
      farmer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      farmer.location.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
            Active
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-accent/20 text-accent-foreground hover:bg-accent/30">
            Pending
          </Badge>
        )
      case "blocked":
        return (
          <Badge className="bg-destructive/10 text-destructive hover:bg-destructive/20">
            Blocked
          </Badge>
        )
      default:
        return null
    }
  }

  const handleViewProfile = (farmer: typeof farmersData[0]) => {
    setSelectedFarmer(farmer)
    setIsDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Farmer Management</h1>
          <p className="text-muted-foreground mt-1">
            Manage registered farmers and their activities
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search farmers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {farmersData.filter((f) => f.status === "active").length}
              </p>
              <p className="text-sm text-muted-foreground">Active Farmers</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-accent/20 rounded-2xl flex items-center justify-center">
              <Filter className="w-6 h-6 text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {farmersData.filter((f) => f.status === "pending").length}
              </p>
              <p className="text-sm text-muted-foreground">Pending Approval</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-destructive/10 rounded-2xl flex items-center justify-center">
              <XCircle className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {farmersData.filter((f) => f.status === "blocked").length}
              </p>
              <p className="text-sm text-muted-foreground">Blocked</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Farmers Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Farmers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Farmer
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Location
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Status
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Total Waste
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredFarmers.map((farmer, index) => (
                  <motion.tr
                    key={farmer.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-border last:border-0 hover:bg-muted/50 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {farmer.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-foreground">{farmer.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {farmer.phone}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {farmer.location}
                      </div>
                    </td>
                    <td className="py-4 px-4">{getStatusBadge(farmer.status)}</td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Trash2 className="w-4 h-4 text-muted-foreground" />
                        <span className="text-foreground">{farmer.totalWaste}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => handleViewProfile(farmer)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Profile
                          </DropdownMenuItem>
                          {farmer.status === "pending" && (
                            <DropdownMenuItem>
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Approve
                            </DropdownMenuItem>
                          )}
                          {farmer.status !== "blocked" && (
                            <DropdownMenuItem className="text-destructive">
                              <XCircle className="w-4 h-4 mr-2" />
                              Block
                            </DropdownMenuItem>
                          )}
                          {farmer.status === "blocked" && (
                            <DropdownMenuItem>
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Unblock
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Profile Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Farmer Profile</DialogTitle>
            <DialogDescription>
              View detailed information about this farmer
            </DialogDescription>
          </DialogHeader>
          {selectedFarmer && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarFallback className="bg-primary/10 text-primary text-xl">
                    {selectedFarmer.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg font-semibold text-foreground">
                    {selectedFarmer.name}
                  </h3>
                  <p className="text-muted-foreground flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {selectedFarmer.location}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted rounded-xl">
                  <p className="text-sm text-muted-foreground">Total Waste</p>
                  <p className="text-lg font-semibold text-foreground">
                    {selectedFarmer.totalWaste}
                  </p>
                </div>
                <div className="p-4 bg-muted rounded-xl">
                  <p className="text-sm text-muted-foreground">Eco-Coins</p>
                  <p className="text-lg font-semibold text-foreground">
                    {selectedFarmer.totalCoins}
                  </p>
                </div>
                <div className="p-4 bg-muted rounded-xl">
                  <p className="text-sm text-muted-foreground">Join Date</p>
                  <p className="text-lg font-semibold text-foreground">
                    {selectedFarmer.joinDate}
                  </p>
                </div>
                <div className="p-4 bg-muted rounded-xl">
                  <p className="text-sm text-muted-foreground">Status</p>
                  <div className="mt-1">{getStatusBadge(selectedFarmer.status)}</div>
                </div>
              </div>
              <div className="p-4 bg-muted rounded-xl">
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="text-lg font-semibold text-foreground">
                  {selectedFarmer.phone}
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
