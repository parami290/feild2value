"use client"

import { motion } from "framer-motion"
import { Eye, Target, RefreshCw, Leaf, ArrowRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useLanguage } from "@/lib/language-context"

export default function AboutPage() {
  const { t } = useLanguage()

  const values = [
    {
      icon: Eye,
      title: t("ourVision"),
      description: t("visionDesc"),
      color: "primary",
    },
    {
      icon: Target,
      title: t("ourMission"),
      description: t("missionDesc"),
      color: "accent",
    },
    {
      icon: RefreshCw,
      title: t("circularEconomy"),
      description: t("circularDesc"),
      color: "secondary",
    },
  ]

  const circularSteps = [
    { label: "Farmer", icon: "farmer" },
    { label: "Waste Collection", icon: "collection" },
    { label: "Processing", icon: "processing" },
    { label: "New Products", icon: "products" },
    { label: "Market", icon: "market" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-3xl mx-auto"
          >
            <span className="inline-block px-4 py-1.5 bg-secondary/50 text-primary text-sm font-medium rounded-full mb-6">
              {t("about")}
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-6 text-balance">
              {t("ourVision")}
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {t("visionDesc")}
            </p>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-12 relative rounded-3xl overflow-hidden shadow-xl"
          >
            <Image
              src="/images/green-fields.jpg"
              alt="Sustainable green agricultural fields"
              width={1200}
              height={500}
              className="w-full h-[300px] sm:h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-transparent" />
          </motion.div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="p-8 h-full hover:shadow-lg transition-all duration-300 group">
                  <motion.div
                    whileHover={{ y: -4 }}
                    transition={{ duration: 0.2 }}
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-colors duration-300 ${
                      value.color === "primary"
                        ? "bg-primary/10 group-hover:bg-primary/20"
                        : value.color === "accent"
                          ? "bg-accent/20 group-hover:bg-accent/30"
                          : "bg-secondary group-hover:bg-secondary/80"
                    }`}
                  >
                    <value.icon
                      className={`w-7 h-7 ${
                        value.color === "primary"
                          ? "text-primary"
                          : value.color === "accent"
                            ? "text-accent-foreground"
                            : "text-primary"
                      }`}
                    />
                  </motion.div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Circular Economy Visualization */}
      <section className="py-24 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              {t("circularEconomy")}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t("circularDesc")}
            </p>
          </motion.div>

          {/* Circular Flow Diagram */}
          <div className="relative max-w-4xl mx-auto">
            <div className="flex flex-wrap justify-center gap-4 md:gap-0 md:flex-nowrap items-center">
              {circularSteps.map((step, index) => (
                <motion.div
                  key={step.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="flex items-center"
                >
                  <div className="flex flex-col items-center">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 bg-primary/10 rounded-full flex items-center justify-center border-2 border-primary/20">
                      <Leaf className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
                    </div>
                    <span className="mt-3 text-sm font-medium text-foreground text-center max-w-20">
                      {step.label}
                    </span>
                  </div>
                  {index < circularSteps.length - 1 && (
                    <ArrowRight className="w-6 h-6 text-primary/40 mx-2 hidden md:block" />
                  )}
                </motion.div>
              ))}
            </div>

            {/* Circular arrow to show loop */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="hidden md:block absolute -bottom-8 left-1/2 -translate-x-1/2"
            >
              <div className="flex items-center gap-2 text-primary/60">
                <RefreshCw className="w-5 h-5" />
                <span className="text-sm">Continuous Cycle</span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Recycling Process Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative rounded-3xl overflow-hidden shadow-xl"
            >
              <Image
                src="/images/recycling-process.jpg"
                alt="Agricultural waste recycling process"
                width={600}
                height={400}
                className="w-full h-[300px] sm:h-[400px] object-cover"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
                Modern Recycling Technology
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                Our partner facilities use advanced technology to transform
                agricultural waste into valuable eco-friendly products, reducing
                environmental impact while creating sustainable materials.
              </p>
              <ul className="space-y-3">
                {["State-of-the-art processing", "Zero-waste approach", "Quality-controlled output", "Environmental compliance"].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-muted-foreground">
                    <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Leaf className="w-3 h-3 text-primary" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Eco Products Section */}
      <section className="py-24 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-2 lg:order-1"
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
                Sustainable Products
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                From packaging materials to organic fertilizers, we help create
                a wide range of eco-friendly products that benefit both farmers
                and the environment.
              </p>
              <ul className="space-y-3">
                {["Biodegradable packaging", "Organic compost", "Biofuel materials", "Construction materials"].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-muted-foreground">
                    <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Leaf className="w-3 h-3 text-primary" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative rounded-3xl overflow-hidden shadow-xl order-1 lg:order-2"
            >
              <Image
                src="/images/eco-products.jpg"
                alt="Eco-friendly products made from agricultural waste"
                width={600}
                height={400}
                className="w-full h-[300px] sm:h-[400px] object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
              Our Commitment
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed">
              We are dedicated to empowering farmers across Sri Lanka with
              technology that transforms agricultural waste into valuable
              resources, creating a sustainable future for all.
            </p>
            <Link href="/register">
              <motion.div
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.97 }}
                className="inline-block"
              >
                <Button
                  size="lg"
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  {t("getStarted")}
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </motion.div>
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
